from fastapi import FastAPI
from routers import wallet, auth

app = FastAPI()

# Include routers
app.include_router(wallet.router, prefix="/api/wallet", tags=["Wallet"])
app.include_router(auth.router, prefix="/api/auth", tags=["Auth"])

@app.get("/")
def home():
    return {"message": "Finora backend is running!"}
