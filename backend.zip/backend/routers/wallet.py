from fastapi import APIRouter

router = APIRouter()

wallet_data = [
    {"mobile": "9876543211", "name": "Priya Patel", "balance": 98000},
    {"mobile": "9876543212", "name": "Amit Kumar", "balance": 156000},
    {"mobile": "9876543213", "name": "Sneha Singh", "balance": 87000},
    {"mobile": "9876543214", "name": "Vikram Reddy", "balance": 210000},
    {"mobile": "9876543215", "name": "Anjali Desai", "balance": 145000},
    {"mobile": "9876543217", "name": "Kavya Nair", "balance": 72000}
]

@router.get("/")
def get_wallets():
    return wallet_data

@router.get("/{mobile}")
def get_wallet_by_mobile(mobile: str):
    for wallet in wallet_data:
        if wallet["mobile"] == mobile:
            return wallet
    return {"error": "User not found"}
