from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import json, os

router = APIRouter()

DATA_FILE = os.path.join(os.path.dirname(__file__), "../data/users.json")

class LoginRequest(BaseModel):
    mobile: str
    password: str

@router.post("/login")
def login_user(req: LoginRequest):
    with open(DATA_FILE, "r") as f:
        users = json.load(f)

    for user in users:
        if user["mobile"] == req.mobile and user["password"] == req.password:
            return {
                "message": "Login successful",
                "user": {
                    "name": user["name"],
                    "mobile": user["mobile"],
                    "balance": user["balance"]
                }
            }

    raise HTTPException(status_code=401, detail="Invalid mobile or password")

@router.get("/users")
def get_all_users():
    with open(DATA_FILE, "r") as f:
        return json.load(f)
